# Mock 스켈레톤 — W1 부트스트랩

세 사람이 서로를 기다리지 않고 병렬 작업을 시작하기 위한 최소 구성입니다.
**A의 메시 없이도, 실제 G-code 없이도 전체 파이프라인이 끝에서 끝까지 돌아갑니다.**

```
mock 퍼블리셔 ──/joint_states──▶ robot_state_publisher ──/tf──▶ RViz
      │                                                          
      └────────────────── ROS-TCP-Endpoint ──────────────────▶ Unity
```

## 무엇이 들어 있나

| 경로 | 내용 | 담당 |
|---|---|---|
| `ros2_ws/src/voron24_description/urdf/voron24_params.xacro` | **모든 치수가 여기 한 곳에** | **A만 수정** |
| `ros2_ws/src/voron24_description/urdf/voron24.urdf.xacro` | mock/real 겸용 URDF | C |
| `ros2_ws/src/voron24_description/urdf/voron24_macros.xacro` | 관성·형상 매크로 | C |
| `ros2_ws/src/voron24_msgs/msg/*.msg` | 커스텀 메시지 3종 | C |
| `ros2_ws/src/voron24_gcode/.../mock_publisher_node.py` | 더미 퍼블리셔 | C |
| `ros2_ws/src/voron24_gcode/.../patterns.py` | 궤적 생성 (ROS 없이 테스트 가능) | C |
| `ros2_ws/src/voron24_gcode/.../corexy.py` | CoreXY 변환 | C |
| `ros2_ws/src/voron24_bringup/launch/mock.launch.py` | 통합 실행 | C |
| `unity/.../Scripts/Robot/*.cs` | 조인트 드라이버 외 | B |
| `tools/contract_check.py` | **계약 위반 자동 검출** | 전원 / CI |
| `tools/smoke_test.sh` | W1 게이트 확인 | 전원 |

**핵심 설계**: URDF가 mock/real 두 벌이 아니라 **한 벌**입니다. `use_meshes:=false`면 박스, `true`면 A의 STL. 조인트 좌표는 어느 쪽이든 `voron24_params.xacro` 하나에서 옵니다. 그래서 메시 교체가 launch 인자 하나로 끝납니다.

---

## 실행

```bash
cd ros2_ws
colcon build --symlink-install
source install/setup.bash

# 1) URDF만 눈으로 확인 (슬라이더로 조인트 조작)
ros2 launch voron24_description display.launch.py

# 2) 통합 — RViz + Unity 엔드포인트 + mock 퍼블리셔
ros2 launch voron24_bringup mock.launch.py

# 축 방향 검증용 (한 축씩 왕복) ★ 처음엔 이걸로
ros2 launch voron24_bringup mock.launch.py pattern:=sweep

# 홈 자세 고정 (노즐이 베드 좌전방 코너에 있는지)
ros2 launch voron24_bringup mock.launch.py pattern:=home

# ROS-TCP-Endpoint를 아직 clone 안 했다면
ros2 launch voron24_bringup mock.launch.py unity:=false
```

### ROS-TCP-Endpoint 설치 (Unity 연결용)

```bash
cd ros2_ws/src
git clone -b main-ros2 https://github.com/Unity-Technologies/ROS-TCP-Endpoint.git
cd .. && colcon build --packages-select ros_tcp_endpoint && source install/setup.bash
```

---

## 계약 검증

커밋 전에 반드시 돌리세요. 링크 이름이나 축이 조용히 어긋나는 걸 잡아냅니다.

```bash
python3 tools/contract_check.py --xacro ros2_ws/src/voron24_description/urdf/voron24.urdf.xacro
python3 tools/contract_check.py --xacro ros2_ws/src/voron24_description/urdf/voron24.urdf.xacro \
        --use-meshes --check-meshes        # A의 메시가 들어온 뒤
```

검출 항목: 링크/조인트 이름, parent-child 관계, 축 방향, 스트로크 리밋, `<inertial>` 누락(Unity 폭발 원인), 메시 scale, 삼각형 예산, **bed_origin이 base_link 자식인지**(Voron 2.4는 베드 고정 — 베드슬링어와 혼동 방지).

### 커밋 훅으로 걸어두기

`.git/hooks/pre-commit`:
```bash
#!/usr/bin/env bash
python3 tools/contract_check.py \
  --xacro ros2_ws/src/voron24_description/urdf/voron24.urdf.xacro || exit 1
```

### 궤적 로직 단독 테스트 (ROS 불필요)

```bash
cd ros2_ws/src/voron24_gcode && python3 -m voron24_gcode.patterns
cd ros2_ws/src/voron24_gcode/voron24_gcode && python3 corexy.py
```

---

## Unity 셋업 (B)

1. 패키지 설치 — Package Manager → Add from git URL
   ```
   https://github.com/Unity-Technologies/URDF-Importer.git?path=/com.unity.robotics.urdf-importer#v0.5.2
   https://github.com/Unity-Technologies/ROS-TCP-Connector.git?path=/com.unity.robotics.ros-tcp-connector
   ```

2. Project Settings → Editor → **Asset Serialization: Force Text**, **Version Control: Visible Meta Files**

3. `ros2_ws/src/voron24_description/` 를 `Assets/URDF/` 아래로 복사

4. mock URDF 생성 후 임포트
   ```bash
   xacro voron24.urdf.xacro use_meshes:=false -o voron24_mock.urdf
   ```
   `.urdf` 우클릭 → **Import Robot from Selected URDF file**
   → **Axis Type: Y Axis**, **Mesh Decomposer: VHACD**

5. 빈 GameObject에 `JointStateSubscriber` + `NozzleTracker` + `ConnectionMonitor` 부착.
   `robotRoot`에 임포트된 로봇을 넣으면 **조인트는 이름으로 자동 연결**됩니다.

6. Robotics → ROS Settings → Protocol **ROS2**, IP/Port 입력

> **ROS 없이 먼저 확인하려면** `LocalMockDriver`를 함께 붙이세요. 엔드포인트가 없어도 Unity 단독으로 조인트가 움직입니다. ROS가 연결되면 자동으로 물러납니다.

> `_pending_msgs/` 안의 두 스크립트는 커스텀 메시지 C# 생성 후에 활성화합니다. 폴더 안 README 참고.

---

## W1 통합 게이트

한 터미널에서 `ros2 launch voron24_bringup mock.launch.py`, 다른 터미널에서:

```bash
bash tools/smoke_test.sh
```

그리고 육안 확인:

- [ ] RViz와 Unity에서 **동시에** 같은 움직임
- [ ] `pattern:=sweep` — X는 오른쪽, Y는 뒤쪽, Z는 위로
- [ ] `joint_z`를 올릴 때 **갠트리만** 올라가고 **베드는 그대로**
- [ ] `pattern:=home` — 노즐이 베드 좌전방 코너
- [ ] Unity `ConnectionMonitor` 오버레이가 CONNECTED

여기까지 통과하면 세 사람이 각자 갈라져도 됩니다.

---

## A가 할 일 (파라미터 채우기)

`voron24_params.xacro`의 `(추정)` 주석이 붙은 값들을 실측으로 교체합니다. **이 파일 하나만 고치면** URDF, RViz, Unity가 전부 따라옵니다.

```xml
<xacro:property name="MEASURED" value="true"/>
<xacro:property name="MEAS_DATE" value="2026-08-15"/>
<xacro:property name="jz_z" value="0.2145"/>   <!-- 근거: 갠트리 Y익스트루전 하면 -->
```

메시는 `meshes/visual/`, `meshes/collision/`에 계약 §4의 파일명으로 넣으면 `use_meshes:=true`가 바로 동작합니다.

---

## 주의

- **`/joint_states` 충돌**: `joint_state_publisher_gui`와 `mock_publisher`를 동시에 띄우면 서로 덮어씁니다. 하나만 실행하세요. (`display.launch.py`는 gui, `mock.launch.py`는 mock_publisher)
- **`patterns.py` ↔ `LocalMockDriver.cs`**: 같은 수식을 두 언어로 구현해 뒀습니다. 한쪽을 고치면 다른 쪽도 고쳐야 합니다. (Unity 단독 폴백용이라 완벽한 동기화가 필수는 아닙니다)
- **`ROS_DOMAIN_ID`**: 팀 전원 동일 값. `~/.bashrc`에 `export ROS_DOMAIN_ID=42`
- **WSL2**: Unity(Windows) ↔ ROS2(WSL) 조합이면 WSL IP가 재부팅마다 바뀝니다. `wsl hostname -I`로 확인하거나 포트 포워딩을 설정하세요.
